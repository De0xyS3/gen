# Script ADMRufu :point_right: [instalacion y actualizaciones](https://github.com/rudi9999/ADMRufu/blob/main/README.md)
![admrufu](https://user-images.githubusercontent.com/67137156/170581224-8270d288-301b-48b6-b60a-2cb11fd45e8a.png)

## menu principal
![admrufu_home2](https://user-images.githubusercontent.com/67137156/170579752-e92115d1-9c53-457b-93ea-1539a5d36044.png)

## administracion de cuentas ssh
![Selection_037](https://user-images.githubusercontent.com/67137156/157490396-1e15d862-5619-4ee2-8699-c9bd12b03385.png)

![Selection_038](https://user-images.githubusercontent.com/67137156/157491226-55dd13bc-5285-4454-90c4-aa4014b461e0.png)
![Selection_039](https://user-images.githubusercontent.com/67137156/157491714-b42fe5a0-38be-4e3f-8d5d-0117ef89e04c.png)

![Selection_040](https://user-images.githubusercontent.com/67137156/157492347-d35ec739-bcd9-4c3d-98cc-70dae9817f38.png)
![Selection_041](https://user-images.githubusercontent.com/67137156/157492562-e382e01b-4299-40d2-8c35-db6c3c410e4d.png)

## administracion de cuentas V2Ray
![Selection_042](https://user-images.githubusercontent.com/67137156/157493735-dee1b28b-39ed-4c7b-80cd-b6fe634c41bc.png)

## configuracion del sistema (activacion de puertos y extras)
![admrufu_conf](https://user-images.githubusercontent.com/67137156/170580003-3cc3b607-fe0f-4f3c-bf86-a11b71956def.png)

## actuaizacion del script (opcion interactiva)
![Selection_044](https://user-images.githubusercontent.com/67137156/157494354-3d665fbc-3728-4c4a-b142-6efce6a274e9.png)

si no hay actualizacion, esta opcion no se muestra!
