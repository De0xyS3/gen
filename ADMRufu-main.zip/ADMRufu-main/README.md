# ADMRufu - En desarrollo
![admrufu_home2](https://user-images.githubusercontent.com/67137156/170579752-e92115d1-9c53-457b-93ea-1539a5d36044.png)
![admrufu_conf](https://user-images.githubusercontent.com/67137156/170580003-3cc3b607-fe0f-4f3c-bf86-a11b71956def.png)

## info sobre el script :point_right: [ADMRufu](https://github.com/rudi9999/ADMRufu/blob/main/info.md)

## Bot generador de key en telegram :point_right: [@ADMRufu_bot](https://t.me/ADMRufu_bot)

## Instalar ADMRufu

`rm -rf install.sh* && wget https://raw.githubusercontent.com/rudi9999/ADMRufu/main/install.sh && chmod +x install.sh* && ./install.sh* --start`

## Actualizar ADMRufu

`rm -rf install.sh* && wget https://raw.githubusercontent.com/rudi9999/ADMRufu/main/install.sh && chmod +x install.sh* && ./install.sh* --update`

## ACTUALIZACION

2022-07-01

1)- generar sub-dominios activa

2)- script generar dominios, nuevo codigo

3)- agrego genera domnio tipo A y NS en paralelo

2022-07-04

1)- fix code 

## Historial de :point_right: [ACTUALIZACIONES](https://github.com/rudi9999/ADMRufu/blob/main/history.md)

#REPORTES DE BUSG POR:

[@Alexmod80](https://t.me/Alexmod80)

[@ander2314](https://t.me/ander2314)

[@arqimidez](https://t.me/arqimidez)

[@Walterlzz](https://t.me/Walterlzz)

[@Nelsongabriel32](https://t.me/Nelsongabriel32)

[@titoec593](https://t.me/titoec593)

[@Rg4bott](https://t.me/Rg4bott)

[@SonicBoom2021](https://t.me/SonicBoom2021)

[@CrakenYT](https://t.me/CrakenYT)
