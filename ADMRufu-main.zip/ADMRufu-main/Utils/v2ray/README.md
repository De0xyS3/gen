INSTALADOR V2RAY

source <(curl -sSL https://raw.githubusercontent.com/rudi9999/ADMRufu/main/Utils/v2ray/v2ray.sh)

INSTALADOR ORIGINAL

source <(curl -sL https://multi.netlify.app/v2ray.sh)
