# Script ADMRufu :point_right: [instalacion y actualizaciones](https://github.com/rudi9999/ADMRufu/blob/main/README.md)

## Updates
2022-03-08

1)- fix visualizacion de actualizacion

2)- fix opcion reboot

3)- fix port node ws

2022-03-09

1)- fix bug backup de usuarios

2022-03-11

1)- (fix bug) en inicio de limitador

2022-03-15

1)- Se agrego soporte para adminstracion de clinetes modos SSH/HWID/TOKEN

2)- Restaurar copis de usuarios online

3)- limitador de conecciones y expirados por separado

2022-03-16

1)- fix banner SSH/DROPBEAR

2)- se agrego un menu para edicion de banner SSH/DROPBEAR

2022-03-20

1)- correcion de bug (cerrado de pueto dropbear) al aplicar/editar banner SSH

2022-03-21

1)- (V2RAY) se bloqueo la lectura de puertos UDP, para mejorar la visualizacion (el bug se esta en estudio.)

2022-03-31

1)- fix code

2022-04-11

1)- add menu manager ssl

2)- fix bug squid

3)- add menu manager squid

2022-04-12

1)- fix code

2022-04-13

1)- fix bug limitador de expirados SSH/HWID/TOKEN

2022-05-05

1)- fix code

2)- se añadio modificacion de Reseller desde el botgen

2022-05-17

1)- añadido WireGard install

2)- añadido administracion de cuentas wireguard

3)- modificacion de menu principal, (dinamico, acorde al protocolo activo)

4)- fix code

2022-05-19

1)- fix wireguard (para redes NAT)

2)- fix monitor de cuentas SSH

2022-05-20

1)- fix menu clientes wireguard

2)- fix monitor de cuentas SSH/HWID/TOKEN

2022-05-26

1)- añadio opcion para ([0] salir del vps). cierra la cesion

2022-06-01

1)- agrego explorador de archivos web (filebrowser)

2)- rescrivio code openvpn

3)- agrego opcion editar apariencia menu de protocolos

2022-06-08

1)- agrego opcion de fix 'inciar con el sistema' DROPBEAR/SSL

2)- fix opcion para ([0] salir del vps). cierra la cesion

2022-07-01

1)- generar sub-dominios activa

2)- script generar dominios, nuevo codigo

3)- agrego genera domnio tipo A y NS en paralelo

2022-07-04

1)- fix code 

# Script ADMRufu :point_right: [instalacion y actualizaciones](https://github.com/rudi9999/ADMRufu/blob/main/README.md)
