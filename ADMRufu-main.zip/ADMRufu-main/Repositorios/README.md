# Lista de APT sources.list

Ubuntu 14, 16, 18.04, 20.04, 20.10, 21.04, 21.10, 22.04

Debian 8, 9, 10, 11
